<?php

require_once "../../../controladores/agentes.controlador.php";
require_once "../../../modelos/agentes.modelo.php";

class imprimirHuellasI{

public $codigo;

public function traerImpresionHuellasI(){

//TRAEMOS LA INFORMACIÓN DE LA VENTA

$itemAgente = "id_agente";
$valorAgente = $this->codigo;


$respuestaAgente = ControladorAgentes::ctrMostrarAgentesPDF($itemAgente, $valorAgente);

//REQUERIMOS LA CLASE TCPDF

require_once('tcpdf_include.php');


$pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);

$pdf->SetMargins(20, 0, 20, 0);

// remove default header/footer
$pdf->setPrintHeader(false);
$pdf->setPrintFooter(false);


$pdf->startPageGroup();

$pdf->AddPage('P', 'FOLIO');


// ---------------------------------------------------------



// ---------------------------------------------------------

$bloque1 = <<<EOF
<br><br><br><br><br><br>
<div  style="text-align: center; "><b>REGISTRO DE FIRMAS</b></div>
<br>
<div style="text-align: justify; font-size: 11px">
Agente: <b>$respuestaAgente[nombre] $respuestaAgente[apellido]</b> 
</div>
<div style="text-align: justify; font-size: 11px">
DPI: <b>$respuestaAgente[dpi] </b> 
</div>

	

	<div style="text-align: justify; font-size: 11px">
	<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
	F:_____________________
	<br><br>
	$respuestaAgente[nombre] $respuestaAgente[apellido]
	</div>

	<div style="text-align: justify; font-size: 11px">
	<br><br><br><br><br><br>
	F:_____________________
	<br><br>
	$respuestaAgente[nombre] $respuestaAgente[apellido]
	</div>
EOF;

$pdf->writeHTML($bloque1, false, false, false, 'false', '');

// Limpiar cualquier contenido del búfer de salida
ob_end_clean();

//SALIDA DEL ARCHIVO 

$pdf->Output('huellasIzq.pdf', 'I');

}

}

$HuellasI = new imprimirHuellasI();
$HuellasI -> codigo = $_GET["codigo"];
$HuellasI -> traerImpresionHuellasI();

?>