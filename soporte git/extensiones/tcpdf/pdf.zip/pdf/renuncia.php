<?php

require_once "../../../controladores/agentes.controlador.php";
require_once "../../../modelos/agentes.modelo.php";

class imprimirContrato{

public $codigo;

public function traerImpresionContrato(){

//TRAEMOS LA INFORMACIÓN DE LA VENTA

$itemAgente = "id_agente";
$valorAgente = $this->codigo;


$respuestaAgente = ControladorAgentes::ctrMostrarAgentesPDF($itemAgente, $valorAgente);

//REQUERIMOS LA CLASE TCPDF

require_once('tcpdf_include.php');


$pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);

// set margins
$pdf->SetMargins(20, 0, 20, 0);

// remove default header/footer
$pdf->setPrintHeader(false);
$pdf->setPrintFooter(false);

$pdf->startPageGroup();


$pdf->AddPage('P', 'FOLIO');


// ---------------------------------------------------------



// ---------------------------------------------------------

$bloque1 = <<<EOF
<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
<div  style="text-align: left; margin-left: 80px;">SEÑORES:<br>PROVITEC, SOCIEDAD ANONIMA</div>

<div style="text-align: justify; font-size: 11px">Por este medio yo $respuestaAgente[nombre] $respuestaAgente[apellido] quien me identifico con dpi ($respuestaAgente[dpi]) presento mi 
renuncia voluntaria e irrevocable, ya que conseguí un nuevo trabajo y agradezco a esta empresa la oportunidad que me dio de 
aprender este trabajo, y de haberme pagado hasta el día de hoy mis prestaciones completas.

</div>
   <div style="text-align: justify; font-size: 11px"> 
    <br>
    <br>
    <br>   <br>
    <br>
    <br>
    <br>   <br>
    <br>
    <br>
    <br>   <br>
    <br>
    <br>
    <br>
    <br>
    <br>
   <table>
        <tr>
        <th>________________________</th>
        </tr>
        <br>
        <tr>
        <th>  $respuestaAgente[nombre] $respuestaAgente[apellido]</th>
        </tr>
   
   </table

</div>
EOF;

$pdf->writeHTML($bloque1, false, false, false, 'false', '');

// Limpiar cualquier contenido del búfer de salida
ob_end_clean();

//SALIDA DEL ARCHIVO 

$pdf->Output('contrato.pdf', 'I');

}

}

$contrato = new imprimirContrato();
$contrato -> codigo = $_GET["codigo"];
$contrato -> traerImpresionContrato();

?>