<?php

require_once "../../../controladores/agentes.controlador.php";
require_once "../../../modelos/agentes.modelo.php";

class imprimirContrato{

public $codigo;

public function traerImpresionContrato(){

//TRAEMOS LA INFORMACIÓN DE LA VENTA

$itemAgente = "id_agente";
$valorAgente = $this->codigo;


$respuestaAgente = ControladorAgentes::ctrMostrarAgentesPDF($itemAgente, $valorAgente);

//REQUERIMOS LA CLASE TCPDF

require_once('tcpdf_include.php');


$pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);

$pdf->SetMargins(10, 0, 10, 0);

// remove default header/footer
$pdf->setPrintHeader(false);
$pdf->setPrintFooter(false);

$pdf->startPageGroup();


$pdf->AddPage('P', 'FOLIO');


// ---------------------------------------------------------



// ---------------------------------------------------------

$bloque1 = <<<EOF
<br><br><br><br><br>
<div  style="text-align: center; "><b>CONTRATO INDIVIDUAL DE TRABAJO</b></div>

<div style="text-align: justify; font-size: 11px">JORGE ADALBERTO CABRERA MENDIZABAL de 35 años de edad, de sexo masculino, 
soltero, guatemalteco, se identifica con Documento Personal de Identificación, Código Único de Identificación (1613 97891 0101) 
MIL SEISIENTOS TRECE, NOVENTA Y SIETE MIL OCHOCIENTOS NOVENTA Y UNO, CIENTO UNO en representación de Provitec Sociedad Anónima., 
ubicada en 11 avenida 28-26 zona 5, Municipio de Guatemala, Del Departamento de Guatemala, por una parte y por la otra:
<font color="white"> _______________________________________</font> de <font color="white"> ____</font> años de edad, sexo <font color="white"> ____________</font>  
nacionalidad Guatemalteca, con residencia en <font color="white"> _______________________________________________</font>  se identifica con Documento personal de Identificación, 
Codigo Único de Identificación (<font color="white"> ______________________</font> ). Quienes para los efectos de este contrato se denominarán "Patrono" y "Trabajador", 
respectivamente celebran el presente CONTRATO INDIVIDUAL DE TRABAJO , contenido en las siguientes cláusulas:


<ol>
    <li>La relación de trabajo inicia el día <font color="white"> _________________________</font> .</li>
    <li>El Trabajador prestara los servicios siguientes: Vigilancia y Servicios de Seguridad.</li>
    <li>Los Servicios serán prestados en: Varios puestos de servicios, situados dentro de la República de Guatemala, según 
    las necesidades del Patrono. Tomando en cuenta la actividad de la empresa que es Servicios de Seguridad Privada.</li>
    <li>. La duración del presente contrato es por tiempo: Indefinido.</li>
    <li> La jornada de trabajo: Por la naturaleza misma de las labores a desempeñar, el trabajador se encuentra comprendido 
    ello no está sujeto a las limitaciones de la jornada de trabajo, así mismo por la naturaleza especial e índole continua del 
    dentro de los casos de excepción que estipula el artículo 124 del Código de Trabajo, literal ¨C¨ y como consecuencia de 
    trabajo, se trabajaran los días de asueto o descanso semanal, cancelándole según artículo 128 del Código de Trabajo.</li>
    <li>El salario será de Q.2,825.10 , más bonificación incentivo de Q.250.00 , según decreto 78/79 modificado por el 37/2001, 
    el cual será pagado en efectivo mensualmente en el propio lugar de trabajo o en las instalaciones de la empresa. Artículo 88,
    del Código de Trabajo.</li>
    <li> Las horas extras, el séptimo día y los días de asueto se pagaran de conformidad con los artículos 121, 124, 126 y 127, 
    del Código de Trabajo.</li>
    <li>El Trabajador debe guardar rigurosamente los secretos técnicos y/o comerciales de la empresa, así como también asuntos 
    administrativos y operativos cuya divulgación ponga en riesgo las operaciones y/o activos de la empresa y/o 
    sus clientes y/o terceras personas.</li>
    <li> Se conviene que el Trabajador prestará los servicios con exclusividad para el Patrono, siempre que haya 
    incompatibilidad entre dos o más relaciones laborales, artículo 18 del Código de Trabajo.</li>
    <li>El trabajador declara conocer que la Empresa presta Servicios de Seguridad Privada, actividad regulada por el Decreto 52-2010 
    del congreso de la Republica. En consecuencia, estará sujeto a los requisitos que en ella se establecen, para su ingreso y el 
    desempeño de sus labores. Si durante la relación infringe lo establecido en la citada ley, podrá darse por terminado este contrato, 
    sin responsabilidad para el patrono.</li>
    <li>El presente Contrato se suscribe en el Municipio de Guatemala, departamento de Guatemala, el día 16/07/2019.</li>
    
</ol>
</div>
   <div style="text-align: justify; font-size: 11px"> 
    <br>
    <br>
    <br> <br>
    <br>
    <br> <br>
    <br>
    <br> <br>
    <br>
    
   <table>
        <tr>
        <th></th>
        <th>________________</th>
        <th></th>
        <th>________________</th>
        <th></th>
        </tr>
        <tr>
        <th></th>
        <th>Firma del trabajador</th>
        <th></th>
        <th>Firma del patrono</th>
        <th></th>
        </tr>
   
   </table

</div>
EOF;

$pdf->writeHTML($bloque1, false, false, false, 'false', '');

// Limpiar cualquier contenido del búfer de salida
ob_end_clean();

//SALIDA DEL ARCHIVO 

$pdf->Output('contrato.pdf', 'I');

}

}

$contrato = new imprimirContrato();
$contrato -> codigo = $_GET["codigo"];
$contrato -> traerImpresionContrato();

?>