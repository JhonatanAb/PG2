<?php

require_once "../../../controladores/agentes.controlador.php";
require_once "../../../modelos/agentes.modelo.php";

class imprimirContrato{

public $codigo;

public function traerImpresionContrato(){

//TRAEMOS LA INFORMACIÓN DE LA VENTA

$itemAgente = "id_agente";
$valorAgente = $this->codigo;


$respuestaAgente = ControladorAgentes::ctrMostrarAgentesPDF($itemAgente, $valorAgente);

//REQUERIMOS LA CLASE TCPDF

require_once('tcpdf_include.php');


$pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);

// set margins
$pdf->SetMargins(20, 0, 20, 0);

// remove default header/footer
$pdf->setPrintHeader(false);
$pdf->setPrintFooter(false);

$pdf->startPageGroup();


$pdf->AddPage('P', 'FOLIO');


// ---------------------------------------------------------



// ---------------------------------------------------------

$bloque1 = <<<EOF
<br><br><br><br>
<div  style="text-align: center; font-size: 14px"><b>CURRICULUM VITAE</b></div><hr>

   <div style="text-align: left; font-size: 13px"> 
    <br>
   
   <table>
   		<tr>
         <th style="width:100px"><img src="../../../$respuestaAgente[foto]"></th>
        </tr>
   </table><br><br>


      <table>

        <tr>
        <th><b>Informacion personal:</b></th>
        </tr>

        <tr>
         <th> </th>
        </tr>

        <tr>
        <th><b>Nombre:</b>  $respuestaAgente[nombre] $respuestaAgente[apellido]</th>
        </tr>
        <tr>
        <th><b>Fecha de nacimiento:</b>  $respuestaAgente[dia] - $respuestaAgente[mes] - $respuestaAgente[ano] </th>
        </tr>
        <tr>
        <th><b>Edad:</b>  $respuestaAgente[edad] años</th>
        </tr>
        <tr>
        <th><b>Estado civil:</b>  $respuestaAgente[estado_civil] </th>
        </tr>
        <tr>
        <th><b>DPI:</b>  $respuestaAgente[dpi] </th>
        </tr>
        <tr>
        <th><b>NIT:</b>  $respuestaAgente[nit] </th>
        </tr>
        <tr>
        <th><b>Direccion:</b>  $respuestaAgente[direccion] </th>
        </tr>
        <tr>
        <th><b>Telefono:</b>  $respuestaAgente[celular] </th>
        </tr>
        <tr>
        <th><b>Correo:</b>  $respuestaAgente[correo] </th>
        </tr>
        <tr>
        <th></th>
        </tr>
        <tr>
        <th></th>
        </tr>

   
   </table>

   <hr>

   <table>
   		<tr>
        <th></th>
        </tr>
        <tr>
        <th></th>
        </tr>
   		<tr>
   			<th><b>Estudios Realizados:</b></th>
   		</tr>

   		<tr>
        <th></th>
        </tr>

        <tr>
        <th><b>Institucion:</b>  $respuestaAgente[escuela] </th>
        </tr>

        <tr>
        <th><b>Ultimo grado aprobado:</b>  $respuestaAgente[grado] </th>
        </tr>

   </table>

</div>
EOF;

$pdf->writeHTML($bloque1, false, false, false, 'false', '');

// Limpiar cualquier contenido del búfer de salida
ob_end_clean();

//SALIDA DEL ARCHIVO 

$pdf->Output('contrato.pdf', 'I');

}

}

$contrato = new imprimirContrato();
$contrato -> codigo = $_GET["codigo"];
$contrato -> traerImpresionContrato();

?>