<?php

require_once "conexion.php";

class ModeloAreas{




	static public function mdlMostrarAreasId($item, $valor){

		if($item != null){

			$stmt = Conexion::conectar()->prepare("SELECT * FROM area WHERE $item = :$item");

			$stmt -> bindParam(":".$item, $valor, PDO::PARAM_STR);

			$stmt -> execute();

			return $stmt -> fetch();

		}else{

			$stmt = Conexion::conectar()->prepare("SELECT * FROM $tabla");

			$stmt -> execute();

			return $stmt -> fetchAll();

		}
		

		$stmt -> close();

		$stmt = null;

	}


	static public function mdlMostrarAreas(){

		$stmt = Conexion::conectar()->prepare("SELECT * FROM area");


		$stmt -> execute();

			return $stmt -> fetchAll();


		$stmt -> close();

		$stmt = null;

	}

	static public function mdlMostrarAreasUsuario($tabla, $usuario){

		$stmt = Conexion::conectar()->prepare("SELECT * FROM $tabla WHERE cobrador = '$usuario'");


		$stmt -> execute();

			return $stmt -> fetchAll();


		$stmt -> close();

		$stmt = null;

	}

	static public function mdlMostrarCuadres(){

		$stmt = Conexion::conectar()->prepare("SELECT * FROM cuadres");


		$stmt -> execute();

			return $stmt -> fetchAll();


		$stmt -> close();

		$stmt = null;

	}

	static public function mdlMostrarAreasTodas(){

		$stmt = Conexion::conectar()->prepare("SELECT area.id_area, area.descripcion, usuarios.nombre as cobrador FROM area LEFT JOIN usuarios ON area.cobrador = usuarios.id");


		$stmt -> execute();

			return $stmt -> fetchAll();


		$stmt -> close();

		$stmt = null;

	}


	/*=============================================
	CREAR 
	=============================================*/

	static public function mdlIngresarArea($tabla, $datos){

		$stmt = Conexion::conectar()->prepare("INSERT INTO $tabla(descripcion) VALUES (:descripcion)");

		$stmt->bindParam(":descripcion", $datos, PDO::PARAM_STR);

		if($stmt->execute()){

			return "ok";

		}else{

			return "error";
		
		}

		$stmt->close();
		$stmt = null;

	}

	/*=============================================
	CREAR 
	=============================================*/

	static public function mdlAsignarArea($tabla, $area, $cobrador){

		$stmt = Conexion::conectar()->prepare("UPDATE area SET cobrador = '$cobrador' WHERE id_area = '$area'");

		

		if($stmt->execute()){

			return "ok";

		}else{

			return "error";
		
		}

		$stmt->close();
		$stmt = null;

	}

	

	/*=============================================
	BORRAR CATEGORIA
	=============================================*/

	static public function mdlBorrarArea($tabla, $datos){

		$stmt = Conexion::conectar()->prepare("DELETE FROM $tabla WHERE id_area = :id");

		$stmt -> bindParam(":id", $datos, PDO::PARAM_INT);

		if($stmt -> execute()){

			return "ok";
		
		}else{

			return "error";	

		}

		$stmt -> close();

		$stmt = null;

	}

	
}

