<?php

require_once "conexion.php";

class ModeloClientes{

	/*=============================================
	MOSTRAR CLIENTES
	=============================================*/

	static public function mdlMostrarClientesBySectorAndLocalidad($id_sector, $nombre_localidad){

	

			$stmt = Conexion::conectar()->prepare("SELECT clientes.id, clientes.nombre, clientes.telefono, clientes.NIT, clientes.localidad, clientes.referencia, UPPER(clientes.id_servicio) as id_servicio, clientes.ultimo_pago, clientes.precio, clientes.ano, sector.descripcion as sector, 
CASE  
WHEN clientes.id_mes = '1' THEN 'Ene'
WHEN clientes.id_mes = '2' THEN 'Feb'
WHEN clientes.id_mes = '3' THEN 'Mar'
WHEN clientes.id_mes = '4' THEN 'Abr'
WHEN clientes.id_mes = '5' THEN 'May'
WHEN clientes.id_mes = '6' THEN 'Jun'
WHEN clientes.id_mes = '7' THEN 'Jul'
WHEN clientes.id_mes = '8' THEN 'Ago'
WHEN clientes.id_mes = '9' THEN 'Sep'
WHEN clientes.id_mes = '10' THEN 'Oct'
WHEN clientes.id_mes = '11' THEN 'Nov'
WHEN clientes.id_mes = '12' THEN 'Dic'
END AS mes
FROM clientes 
INNER JOIN sector 
ON clientes.id_sector = sector.id_sector
WHERE clientes.estado = 1 && clientes.id_sector = '$id_sector' && clientes.localidad = '$nombre_localidad'  ORDER BY clientes.referencia");

			$stmt -> execute();

			return $stmt -> fetchAll();

		$stmt -> close();

		$stmt = null;

}

	/*=============================================
	MOSTRAR CLIENTES
	=============================================*/

	static public function mdlClientesNuevosSinCobrar($usuario){

			$stmt = Conexion::conectar()->prepare("SELECT clientes.id as id, clientes.nombre as nombre, mes.nombre as mes, clientes.ano, clientes.telefono as telefono, clientes.NIT as NIT, clientes.referencia as referencia, clientes.localidad as localidad, clientes.id_servicio as servicio, clientes.precio as precio, clientes.ultimo_pago as ultimo_pago, clientes.estado, clientes.observacion, sector.descripcion as sector, area.descripcion as area, clientes.fecha_instalacion, DATEDIFF(NOW(),clientes.fecha_instalacion) as dias FROM clientes INNER JOIN area ON clientes.id_area = area.id_area INNER JOIN sector ON clientes.id_sector = sector.id_sector INNER JOIN mes ON clientes.id_mes = mes.id_mes WHERE clientes.estado = '1' && (clientes.ultimo_pago IS NULL || clientes.ultimo_pago = '0000-00-00' || clientes.ultimo_pago = '') && area.cobrador = '$usuario' && (DATEDIFF(NOW(),clientes.fecha_instalacion) >= 31 || DATEDIFF(NOW(),clientes.fecha_instalacion) IS NULL)");

			$stmt -> execute();

			return $stmt -> fetchAll();

		$stmt -> close();

		$stmt = null;

	}

	/*=============================================
	MOSTRAR CLIENTES
	=============================================*/

	static public function mdlClientesAtrasados($usuario){

			$stmt = Conexion::conectar()->prepare("SELECT clientes.id as id, clientes.nombre as nombre, mes.nombre as mes, clientes.ano, clientes.telefono as telefono, clientes.NIT as NIT, clientes.referencia as referencia, clientes.localidad as localidad, clientes.id_servicio as servicio, clientes.precio as precio, clientes.ultimo_pago as ultimo_pago, clientes.estado, clientes.observacion, sector.descripcion as sector, area.descripcion as area, clientes.fecha_instalacion, DATEDIFF(NOW(),clientes.ultimo_pago) as dias FROM clientes INNER JOIN area ON clientes.id_area = area.id_area INNER JOIN sector ON clientes.id_sector = sector.id_sector INNER JOIN mes ON clientes.id_mes = mes.id_mes WHERE clientes.estado = '1'  && area.cobrador = '$usuario' && (DATEDIFF(NOW(),clientes.ultimo_pago) >= 40 || DATEDIFF(NOW(),clientes.ultimo_pago) IS NULL) && DATEDIFF(NOW(),clientes.fecha_instalacion) >= 31");

			$stmt -> execute();

			return $stmt -> fetchAll();

		$stmt -> close();

		$stmt = null;

	}
	/*=============================================
	MOSTRAR CLIENTES
	=============================================*/

	static public function mdlMostrarClientes($tabla, $item, $valor){

		if($item != null){

			$stmt = Conexion::conectar()->prepare("SELECT * FROM $tabla WHERE $item = :$item");

			$stmt -> bindParam(":".$item, $valor, PDO::PARAM_STR);

			$stmt -> execute();

			return $stmt -> fetch();

		}else{

			$stmt = Conexion::conectar()->prepare("SELECT  mes.nombre as mes, clientes.ano, clientes.id as id, clientes.nombre as nombre, clientes.telefono as telefono, clientes.NIT as NIT, clientes.referencia as referencia, clientes.localidad as localidad, clientes.id_servicio as servicio, clientes.precio as precio, clientes.ultimo_pago as ultimo_pago, clientes.estado, clientes.observacion, sector.descripcion as sector, area.descripcion as area FROM clientes INNER JOIN area ON clientes.id_area = area.id_area INNER JOIN sector ON clientes.id_sector = sector.id_sector INNER JOIN mes ON clientes.id_mes = mes.id_mes WHERE clientes.estado = '1'");

			$stmt -> execute();

			return $stmt -> fetchAll();

		}

		$stmt -> close();

		$stmt = null;

	}

	/*=============================================
	MOSTRAR CLIENTES
	=============================================*/

	static public function mdlMostrarClientesCd($tabla, $item, $valor){

	

			$stmt = Conexion::conectar()->prepare("SELECT  mes.nombre as mes, clientes.ano, clientes.id as id, clientes.nombre as nombre, clientes.telefono as telefono, clientes.NIT as NIT, clientes.referencia as referencia, clientes.localidad as localidad, clientes.id_servicio as servicio, clientes.precio as precio, clientes.ultimo_pago as ultimo_pago, clientes.estado, clientes.observacion, sector.descripcion as sector, area.descripcion as area FROM clientes INNER JOIN area ON clientes.id_area = area.id_area INNER JOIN sector ON clientes.id_sector = sector.id_sector INNER JOIN mes ON clientes.id_mes = mes.id_mes WHERE clientes.estado = '1' && clientes.id_area = 24");

			$stmt -> execute();

			return $stmt -> fetchAll();

		$stmt -> close();

		$stmt = null;

	}

	/*=============================================
	MOSTRAR CLIENTES
	=============================================*/

	static public function mdlMostrarClientesSuspendidos($tabla, $item, $valor){


			$stmt = Conexion::conectar()->prepare("SELECT  mes.nombre as mes, clientes.ano, clientes.id as id, clientes.nombre as nombre, clientes.telefono as telefono, clientes.NIT as NIT, clientes.referencia as referencia, clientes.localidad as localidad, clientes.id_servicio as servicio, clientes.precio as precio, clientes.ultimo_pago as ultimo_pago, clientes.estado, sector.descripcion as sector, area.descripcion as area FROM clientes INNER JOIN area ON clientes.id_area = area.id_area INNER JOIN sector ON clientes.id_sector = sector.id_sector INNER JOIN mes ON clientes.id_mes = mes.id_mes WHERE clientes.estado = '0'");

			$stmt -> execute();

			return $stmt -> fetchAll();

		$stmt -> close();

		$stmt = null;

	}

	/*=============================================
	MOSTRAR CLIENTES
	=============================================*/

	static public function mdlMostrarClientesArea($tabla, $area){


			$stmt = Conexion::conectar()->prepare("SELECT  mes.nombre as mes, clientes.ano, clientes.id as id, clientes.nombre as nombre, clientes.telefono as telefono, clientes.NIT as NIT, clientes.referencia as referencia, clientes.localidad as localidad, clientes.id_servicio as servicio, clientes.precio as precio, clientes.ultimo_pago as ultimo_pago, clientes.estado, sector.descripcion as sector, area.descripcion as area FROM clientes INNER JOIN area ON clientes.id_area = area.id_area INNER JOIN sector ON clientes.id_sector = sector.id_sector INNER JOIN mes ON clientes.id_mes = mes.id_mes WHERE area.id_area = '$area' && clientes.estado = '1'");

			$stmt -> execute();

			return $stmt -> fetchAll();


		$stmt -> close();

		$stmt = null;

	}

	/*=============================================
	MOSTRAR CLIENTES
	=============================================*/

	static public function mdlMostrarClientesCobrador($cobrador){


			$stmt = Conexion::conectar()->prepare("SELECT clientes.id as id, clientes.nombre as nombre, clientes.telefono as telefono, clientes.NIT as NIT, area.descripcion as area, sector.descripcion as sector, clientes.localidad as localidad, clientes.referencia as referencia, clientes.ultimo_pago as ultimo_pago, clientes.id_mes, clientes.id_servicio as servicio, clientes.precio, mes.nombre as mes FROM clientes INNER JOIN area ON clientes.id_area = area.id_area INNER JOIN sector ON clientes.id_sector = sector.id_sector INNER JOIN mes ON clientes.id_mes = mes.id_mes WHERE area.cobrador = '$cobrador' && clientes.estado = 1");

			$stmt -> execute();

			return $stmt -> fetchAll();

		
		$stmt -> close();

		$stmt = null;

	}
	
		/*=============================================
	MOSTRAR CLIENTES
	=============================================*/

	static public function mdlMostrarClientesAlameda(){


			$stmt = Conexion::conectar()->prepare("SELECT clientes.id as id, clientes.nombre as nombre, clientes.telefono as telefono, clientes.NIT as NIT, area.descripcion as area, sector.descripcion as sector, clientes.localidad as localidad, clientes.referencia as referencia, clientes.ultimo_pago as ultimo_pago, clientes.id_mes, clientes.id_servicio as servicio, clientes.precio, mes.nombre as mes FROM clientes INNER JOIN area ON clientes.id_area = area.id_area INNER JOIN sector ON clientes.id_sector = sector.id_sector INNER JOIN mes ON clientes.id_mes = mes.id_mes WHERE area.id_area = 51 && clientes.estado = 1");

			$stmt -> execute();

			return $stmt -> fetchAll();

		
		$stmt -> close();

		$stmt = null;

	}


	/*=============================================
	MOSTRAR CLIENTES
	=============================================*/

	static public function mdlMostrarClientesCobrar($idCliente){

		

			$stmt = Conexion::conectar()->prepare("

				SELECT clientes.id as idcliente, clientes.nombre as nombre, clientes.telefono as telefono, clientes.NIT as nit, clientes.id_sector as idsector, clientes.id_area as idarea, clientes.ano as ano, area.descripcion as area, sector.descripcion as sector, clientes.localidad as localidad, clientes.referencia as referencia, clientes.ultimo_pago as ultimo_pago, clientes.id_mes,  clientes.id_servicio as servicio, clientes.precio as precio, mes.nombre as mes, mes.id_mes as idmes FROM clientes INNER JOIN area ON clientes.id_area = area.id_area INNER JOIN sector ON clientes.id_sector = sector.id_sector INNER JOIN mes ON clientes.id_mes = mes.id_mes WHERE clientes.id = '$idCliente'");


			$stmt -> execute();

			return $stmt -> fetch();

		

		$stmt -> close();

		$stmt = null;

	}

		/*=============================================
	MOSTRAR CLIENTES
	=============================================*/

	static public function mdlMostrarDatosFacturaTemporal($idClienteFT, $fechaFT){


			$stmt = Conexion::conectar()->prepare("SELECT * FROM fac_temp WHERE id_cliente = $idClienteFT && estado = 0 && fecha_guardo = '$fechaFT' ORDER BY id DESC LIMIT 1");

			$stmt -> execute();

			return $stmt -> fetch();

		
		$stmt -> close();

		$stmt = null;

	}


/*=============================================
	EDITAR CLIENTE
	=============================================*/

	static public function mdlCobrarCliente($tabla, $datos, $nuevomes, $fechaCorta){

		$stmt = Conexion::conectar()->prepare("INSERT INTO $tabla(fecha_pago, id_mes, id_cliente, id_servicio, ano, precio, comprobante, usuario, tipo, doc, id_area, id_sector, cant_mes) VALUES (:fecha_pago, :id_mes, :id_cliente, :id_servicio, :ano, :precio, :comprobante, :usuario, :tipo, :doc, :id_area, :id_sector, :cant_mes);
			UPDATE clientes SET id_mes = '$nuevomes', ano = :ano, ultimo_pago = '$fechaCorta' WHERE id = :id_cliente");

		$stmt->bindParam(":fecha_pago", $datos["fecha_pago"], PDO::PARAM_STR);
		$stmt->bindParam(":id_mes", $datos["id_mes"], PDO::PARAM_STR);
		$stmt->bindParam(":id_cliente", $datos["id_cliente"], PDO::PARAM_STR);
		$stmt->bindParam(":id_servicio", $datos["id_servicio"], PDO::PARAM_STR);
		$stmt->bindParam(":ano", $datos["ano"], PDO::PARAM_STR);
		$stmt->bindParam(":precio", $datos["precio"], PDO::PARAM_STR);
		$stmt->bindParam(":comprobante", $datos["comprobante"], PDO::PARAM_STR);
		$stmt->bindParam(":usuario", $datos["usuario"], PDO::PARAM_STR);
		$stmt->bindParam(":tipo", $datos["tipo"], PDO::PARAM_STR);
		$stmt->bindParam(":doc", $datos["doc"], PDO::PARAM_STR);
		$stmt->bindParam(":id_area", $datos["id_area"], PDO::PARAM_STR);
		$stmt->bindParam(":id_sector", $datos["id_sector"], PDO::PARAM_STR);
		$stmt->bindParam(":cant_mes", $datos["cant_mes"], PDO::PARAM_STR);

		if($stmt->execute()){

			return "ok";

		}else{

			return "error";
		
		}

		$stmt->close();
		$stmt = null;

	}


	/*=============================================
	EDITAR CLIENTE
	=============================================*/

	static public function mdlGuardarFacTemp($tabla, $datos, $nuevomes, $fechaCorta){

		$stmt = Conexion::conectar()->prepare("INSERT INTO $tabla(id_cliente, receptor_nit, receptor_nombre, fecha_hora, autorizacion, serie, numero, usuario, estado, fecha_guardo, total, descripcion) VALUES (:id_cliente, :receptor_nit, :receptor_nombre, :fecha_hora, :autorizacion, :serie, :numero, :usuario, '0', :fecha_guardo, :total, :descripcion)");

		$stmt->bindParam(":id_cliente", $datos["id_cliente"], PDO::PARAM_STR);
		$stmt->bindParam(":receptor_nit", $datos["receptor_nit"], PDO::PARAM_STR);
		$stmt->bindParam(":receptor_nombre", $datos["receptor_nombre"], PDO::PARAM_STR);
		$stmt->bindParam(":fecha_hora", $datos["fecha_hora"], PDO::PARAM_STR);
		$stmt->bindParam(":autorizacion", $datos["autorizacion"], PDO::PARAM_STR);
		$stmt->bindParam(":serie", $datos["serie"], PDO::PARAM_STR);
		$stmt->bindParam(":numero", $datos["numero"], PDO::PARAM_STR);
		$stmt->bindParam(":usuario", $datos["usuario"], PDO::PARAM_STR);
		$stmt->bindParam(":fecha_guardo", $datos["fecha_guardo"], PDO::PARAM_STR);
		$stmt->bindParam(":total", $datos["total"], PDO::PARAM_STR);
		$stmt->bindParam(":descripcion", $datos["descripcion"], PDO::PARAM_STR);

		if($stmt->execute()){

			return "ok";

		}else{

			return "error";
		
		}

		$stmt->close();
		$stmt = null;

	}







	/*=============================================
	CREAR CLIENTE
	=============================================*/

	static public function mdlIngresarCliente($tabla, $datos){

		$stmt = Conexion::conectar()->prepare("INSERT INTO $tabla(nombre, telefono, NIT, id_area, id_sector, referencia, localidad, id_servicio, id_mes, ano, precio, fecha_instalacion, observacion, instalador, iddir) VALUES (:nombre, :telefono, :nit, :id_area, :id_sector, :referencia, :localidad, :id_servicio, :id_mes, :ano, :precio, :fecha_instalacion, :observacion, :instalador, :iddir)");

		$stmt->bindParam(":nombre", $datos["nombre"], PDO::PARAM_STR);
		$stmt->bindParam(":telefono", $datos["telefono"], PDO::PARAM_STR);
		$stmt->bindParam(":nit", $datos["nit"], PDO::PARAM_STR);
		$stmt->bindParam(":id_area", $datos["id_area"], PDO::PARAM_STR);
		$stmt->bindParam(":id_sector", $datos["id_sector"], PDO::PARAM_STR);
		$stmt->bindParam(":referencia", $datos["referencia"], PDO::PARAM_STR);
		$stmt->bindParam(":localidad", $datos["localidad"], PDO::PARAM_STR);
		$stmt->bindParam(":id_servicio", $datos["id_servicio"], PDO::PARAM_STR);
		$stmt->bindParam(":id_mes", $datos["id_mes"], PDO::PARAM_STR);
		$stmt->bindParam(":ano", $datos["ano"], PDO::PARAM_STR);
		$stmt->bindParam(":precio", $datos["precio"], PDO::PARAM_STR);
		$stmt->bindParam(":fecha_instalacion", $datos["fecha_instalacion"], PDO::PARAM_STR);
		$stmt->bindParam(":observacion", $datos["observacion"], PDO::PARAM_STR);
		$stmt->bindParam(":instalador", $datos["instalador"], PDO::PARAM_STR);
		$stmt->bindParam(":iddir", $datos["iddir"], PDO::PARAM_STR);


		if($stmt->execute()){

			return "ok";

		}else{

			return "error";
		
		}

		$stmt->close();
		$stmt = null;

	}

		/*=============================================
	EDITAR CLIENTE
	=============================================*/

	static public function mdlEditarCliente($tabla, $datos){

		$stmt = Conexion::conectar()->prepare("UPDATE $tabla SET nombre = :nombre, telefono = :telefono, NIT = :nit, referencia = :referencia, localidad = :localidad, id_servicio = :id_servicio, id_mes = :id_mes, id_area = :id_area, id_sector = :id_sector, ano = :ano, precio = :precio, observacion = :observacion, fecha_instalacion = :fecha_instalacion, iddir = :iddir WHERE id = :id");

		$stmt->bindParam(":id", $datos["id"], PDO::PARAM_INT);
		$stmt->bindParam(":nombre", $datos["nombre"], PDO::PARAM_STR);
		$stmt->bindParam(":telefono", $datos["telefono"], PDO::PARAM_STR);
		$stmt->bindParam(":nit", $datos["nit"], PDO::PARAM_STR);
		$stmt->bindParam(":referencia", $datos["referencia"], PDO::PARAM_STR);
		$stmt->bindParam(":localidad", $datos["localidad"], PDO::PARAM_STR);
		$stmt->bindParam(":id_servicio", $datos["id_servicio"], PDO::PARAM_STR);
		$stmt->bindParam(":id_mes", $datos["id_mes"], PDO::PARAM_STR);
		$stmt->bindParam(":id_area", $datos["id_area"], PDO::PARAM_STR);
		$stmt->bindParam(":id_sector", $datos["id_sector"], PDO::PARAM_STR);
		$stmt->bindParam(":ano", $datos["ano"], PDO::PARAM_STR);
		$stmt->bindParam(":precio", $datos["precio"], PDO::PARAM_STR);
		$stmt->bindParam(":observacion", $datos["observacion"], PDO::PARAM_STR);
		$stmt->bindParam(":fecha_instalacion", $datos["fecha_instalacion"], PDO::PARAM_STR);
		$stmt->bindParam(":iddir", $datos["iddir"], PDO::PARAM_STR);



		if($stmt->execute()){

			return "ok";

		}else{

			return "error";
		
		}

		$stmt->close();
		$stmt = null;

	}

	/*=============================================
	ELIMINAR CLIENTE
	=============================================*/

	static public function mdlEliminarCliente($tabla, $datos){

		$stmt = Conexion::conectar()->prepare("DELETE FROM $tabla WHERE id = :id");

		$stmt -> bindParam(":id", $datos, PDO::PARAM_INT);

		if($stmt -> execute()){

			return "ok";
		
		}else{

			return "error";	

		}

		$stmt -> close();

		$stmt = null;

	}

	/*=============================================
	ACTUALIZAR CLIENTE
	=============================================*/

	static public function mdlActualizarCliente($tabla, $item1, $valor1, $item2, $valor2){

		$stmt = Conexion::conectar()->prepare("UPDATE $tabla SET $item1 = :$item1  WHERE $item2 = :$item2");

		$stmt -> bindParam(":".$item1, $valor1, PDO::PARAM_STR);

		$stmt -> bindParam(":".$item2, $valor2, PDO::PARAM_STR);

		if($stmt -> execute()){

			return "ok";
		
		}else{

			return "error";	

		}

		$stmt -> close();

		$stmt = null;

	}

	/*=============================================
	ACTUALIZAR CLIENTE
	=============================================*/

	static public function mdlGuardarSuspension($cliente, $fecha, $fechaActual, $observacion, $usuario){

		$stmt = Conexion::conectar()->prepare("UPDATE clientes SET estado = '0'  WHERE id = '$cliente';
			INSERT INTO bitacora (cliente, evento, observacion, fecha, usuario) VALUES ('$cliente', 'Suspension', '$observacion', '$fechaActual', '$usuario')");

		

		if($stmt -> execute()){

			return "ok";
		
		}else{

			return "error";	

		}

		$stmt -> close();

		$stmt = null;

	}


	/*=============================================
	ACTUALIZAR CLIENTE
	=============================================*/

	static public function mdlAnularPago($cliente, $idcobro, $viejomes, $ano, $fecha, $fechaActual, $observacion, $usuario){

		$stmt = Conexion::conectar()->prepare("UPDATE clientes SET id_mes = '$viejomes', ano = ano - $ano  WHERE id = '$cliente';
			UPDATE pago SET  estado = '3' WHERE id_pago = '$idcobro';
			INSERT INTO bitacora (cliente, evento, observacion, fecha, usuario) VALUES ('$cliente', 'Anulado', '$observacion', '$fechaActual', '$usuario')");

		

		if($stmt -> execute()){

			return "ok";
		
		}else{

			return "error";	

		}

		$stmt -> close();

		$stmt = null;

	}

/*=============================================
	ACTUALIZAR CLIENTE
	=============================================*/

	static public function mdlGuardarReconexion($cliente, $fecha, $fechaActual, $observacion, $usuario){

		$stmt = Conexion::conectar()->prepare("UPDATE clientes SET estado = '1'  WHERE id = '$cliente';
			INSERT INTO bitacora (cliente, evento, observacion, fecha, usuario) VALUES ('$cliente', 'Reconexion', '$observacion', '$fechaActual', '$usuario')");

		

		if($stmt -> execute()){

			return "ok";
		
		}else{

			return "error";	

		}

		$stmt -> close();

		$stmt = null;

	}

	/*=============================================
	MOSTRAR CLIENTES IMPRIME
	=============================================*/

	static public function MdlMostrarListadoClientes($tabla, $servicio, $area){

		/**
		 si servicio es cable 
		 */if ($servicio != "TODOS") {
		 	# code...
	
			$stmt = Conexion::conectar()->prepare("SELECT clientes.id, clientes.nombre, clientes.telefono, clientes.NIT, clientes.localidad, clientes.referencia, clientes.id_servicio, clientes.ultimo_pago, clientes.precio, clientes.ano, sector.descripcion as sector, 
CASE  
WHEN clientes.id_mes = '1' THEN 'ENERO'
WHEN clientes.id_mes = '2' THEN 'FEBRERO'
WHEN clientes.id_mes = '3' THEN 'MARZO'
WHEN clientes.id_mes = '4' THEN 'ABRIL'
WHEN clientes.id_mes = '5' THEN 'MAYO'
WHEN clientes.id_mes = '6' THEN 'JUNIO'
WHEN clientes.id_mes = '7' THEN 'JULIO'
WHEN clientes.id_mes = '8' THEN 'AGOSTO'
WHEN clientes.id_mes = '9' THEN 'SEPTIEMBRE'
WHEN clientes.id_mes = '10' THEN 'OCTUBRE'
WHEN clientes.id_mes = '11' THEN 'NOVIEMBRE'
WHEN clientes.id_mes = '12' THEN 'DICIEMBRE'
END AS mes
FROM clientes 
INNER JOIN sector 
ON clientes.id_sector = sector.id_sector
WHERE clientes.estado = 1 && clientes.id_area = '$area' && clientes.id_servicio = '$servicio'  ORDER BY clientes.id_sector, clientes.iddir, clientes.localidad, clientes.referencia ");

			$stmt -> execute();

			return $stmt -> fetchAll();
		}

		


			/**
		 si servicio no es ninguno
		 */if ($servicio == "TODOS") {
	
					$stmt = Conexion::conectar()->prepare("SELECT clientes.id, clientes.nombre, clientes.telefono, clientes.NIT, clientes.localidad, clientes.referencia, clientes.id_servicio, clientes.ultimo_pago, clientes.precio, clientes.ano, sector.descripcion as sector, 
CASE  
WHEN clientes.id_mes = '1' THEN 'ENERO'
WHEN clientes.id_mes = '2' THEN 'FEBRERO'
WHEN clientes.id_mes = '3' THEN 'MARZO'
WHEN clientes.id_mes = '4' THEN 'ABRIL'
WHEN clientes.id_mes = '5' THEN 'MAYO'
WHEN clientes.id_mes = '6' THEN 'JUNIO'
WHEN clientes.id_mes = '7' THEN 'JULIO'
WHEN clientes.id_mes = '8' THEN 'AGOSTO'
WHEN clientes.id_mes = '9' THEN 'SEPTIEMBRE'
WHEN clientes.id_mes = '10' THEN 'OCTUBRE'
WHEN clientes.id_mes = '11' THEN 'NOVIEMBRE'
WHEN clientes.id_mes = '12' THEN 'DICIEMBRE'
END AS mes
FROM clientes 
INNER JOIN sector 
ON clientes.id_sector = sector.id_sector
WHERE clientes.estado = 1 && clientes.id_area = '$area'  ORDER BY clientes.id_sector, clientes.iddir, clientes.localidad, clientes.referencia");


			$stmt -> execute();

			return $stmt -> fetchAll();

			}


		$stmt -> close();

		$stmt = null;

	}

	/*=============================================
	MOSTRAR CLIENTES IMPRIME
	=============================================*/

	static public function MdlMostrarListadoClientesDeuda($tabla, $servicio, $area, $fecha){

		/**
		 si servicio es cable 
		 */if ($servicio != "TODOS") {
		 	# code...
	
			$stmt = Conexion::conectar()->prepare("SELECT clientes.id, clientes.nombre, clientes.telefono, clientes.NIT, clientes.localidad, clientes.referencia, clientes.id_servicio, clientes.ultimo_pago, clientes.precio, clientes.ano, sector.descripcion as sector, 
CASE  
WHEN clientes.id_mes = '1' THEN 'ENERO'
WHEN clientes.id_mes = '2' THEN 'FEBRERO'
WHEN clientes.id_mes = '3' THEN 'MARZO'
WHEN clientes.id_mes = '4' THEN 'ABRIL'
WHEN clientes.id_mes = '5' THEN 'MAYO'
WHEN clientes.id_mes = '6' THEN 'JUNIO'
WHEN clientes.id_mes = '7' THEN 'JULIO'
WHEN clientes.id_mes = '8' THEN 'AGOSTO'
WHEN clientes.id_mes = '9' THEN 'SEPTIEMBRE'
WHEN clientes.id_mes = '10' THEN 'OCTUBRE'
WHEN clientes.id_mes = '11' THEN 'NOVIEMBRE'
WHEN clientes.id_mes = '12' THEN 'DICIEMBRE'
END AS mes
FROM clientes 
INNER JOIN sector 
ON clientes.id_sector = sector.id_sector
WHERE clientes.estado = 1 && clientes.id_area = '$area' && clientes.id_servicio = '$servicio' && (CONVERT(CONCAT(ano,'-',id_mes,'-01'),DATE)) <= '$fecha'   ORDER BY clientes.id_sector, clientes.iddir, clientes.localidad, clientes.referencia ");

			$stmt -> execute();

			return $stmt -> fetchAll();
		}

		


			/**
		 si servicio no es ninguno
		 */if ($servicio == "TODOS") {
	
					$stmt = Conexion::conectar()->prepare("SELECT clientes.id, clientes.nombre, clientes.telefono, clientes.NIT, clientes.localidad, clientes.referencia, clientes.id_servicio, clientes.ultimo_pago, clientes.precio, clientes.ano, sector.descripcion as sector, 
CASE  
WHEN clientes.id_mes = '1' THEN 'ENERO'
WHEN clientes.id_mes = '2' THEN 'FEBRERO'
WHEN clientes.id_mes = '3' THEN 'MARZO'
WHEN clientes.id_mes = '4' THEN 'ABRIL'
WHEN clientes.id_mes = '5' THEN 'MAYO'
WHEN clientes.id_mes = '6' THEN 'JUNIO'
WHEN clientes.id_mes = '7' THEN 'JULIO'
WHEN clientes.id_mes = '8' THEN 'AGOSTO'
WHEN clientes.id_mes = '9' THEN 'SEPTIEMBRE'
WHEN clientes.id_mes = '10' THEN 'OCTUBRE'
WHEN clientes.id_mes = '11' THEN 'NOVIEMBRE'
WHEN clientes.id_mes = '12' THEN 'DICIEMBRE'
END AS mes
FROM clientes 
INNER JOIN sector 
ON clientes.id_sector = sector.id_sector
WHERE clientes.estado = 1 && clientes.id_area = '$area' && (CONVERT(CONCAT(clientes.ano,'-',clientes.id_mes,'-01'),DATE)) <= '$fecha'  ORDER BY clientes.id_sector, clientes.iddir, clientes.localidad, clientes.referencia");


			$stmt -> execute();

			return $stmt -> fetchAll();

			}


		$stmt -> close();

		$stmt = null;

	}


}