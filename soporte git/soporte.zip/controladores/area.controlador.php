<?php

class ControladorAreas{



	static public function ctrMostrarAreasId($item, $valor){

	

		$respuesta = ModeloAreas::mdlMostrarAreasId($item, $valor);

		return $respuesta;
	}

	static public function ctrMostrarAreas(){

		$respuesta = ModeloAreas::mdlMostrarAreas();

		return $respuesta;
	
	}



	static public function ctrMostrarAreasTodas(){

		$respuesta = ModeloAreas::mdlMostrarAreasTodas();

		return $respuesta;
	
	}

/*=============================================
	CREAR 
	=============================================*/

	static public function ctrCrearArea(){

		if(isset($_POST["nuevaArea"])){

			if(preg_match('/^[a-zA-Z0-9ñÑáéíóúÁÉÍÓÚ ]+$/', $_POST["nuevaArea"])){

				$tabla = "area";

				$datos = $_POST["nuevaArea"];

				$respuesta = ModeloAreas::mdlIngresarArea($tabla, $datos);

				if($respuesta == "ok"){

					echo'<script>

					Swal.fire({
						  type: "success",
						  title: "el area ha sido guardada correctamente",
						  showConfirmButton: true,
						  confirmButtonText: "Cerrar"
						  }).then(function(result){
									if (result.value) {

									window.location = "areas";

									}
								})

					</script>';

				}


			}else{

				echo'<script>

					Swal({
						  type: "error",
						  title: "¡el area no puede ir vacía o llevar caracteres especiales!",
						  showConfirmButton: true,
						  confirmButtonText: "Cerrar"
						  }).then(function(result){
							if (result.value) {

							window.location = "areas";

							}
						})

			  	</script>';

			}

		}

	}


/*=============================================
	CREAR 
	=============================================*/

	static public function ctrAsignarArea(){

		if(isset($_POST["idArea"])){

			if(preg_match('/^[a-zA-Z0-9ñÑáéíóúÁÉÍÓÚ ]+$/', $_POST["idArea"])){

				$tabla = "area";

				$area = $_POST["idArea"];
				$cobrador = $_POST["nuevoCobrador"];

				$respuesta = ModeloAreas::mdlAsignarArea($tabla, $area, $cobrador);

				if($respuesta == "ok"){

					echo'<script>

					Swal.fire({
						  type: "success",
						  title: "Cobrador asignado correctamente",
						  showConfirmButton: true,
						  confirmButtonText: "Cerrar"
						  }).then(function(result){
									if (result.value) {

									window.location = "areas";

									}
								})

					</script>';

				}


			}else{

				echo'<script>

					Swal({
						  type: "error",
						  title: "¡error!",
						  showConfirmButton: true,
						  confirmButtonText: "Cerrar"
						  }).then(function(result){
							if (result.value) {

							window.location = "areas";

							}
						})

			  	</script>';

			}

		}

	}



/*=============================================
	BORRAR area
	=============================================*/

	static public function ctrBorrarArea(){

		if(isset($_GET["idArea"])){

			$tabla ="area";
			$datos = $_GET["idArea"];

			$respuesta = ModeloAreas::mdlBorrarArea($tabla, $datos);

			if($respuesta == "ok"){

				echo'<script>

					Swal.fire({
						  type: "success",
						  title: "El area ha sido borrada correctamente",
						  showConfirmButton: true,
						  confirmButtonText: "Cerrar"
						  }).then(function(result){
									if (result.value) {

									window.location = "areas";

									}
								})

					</script>';
			}
		}
		
	}




}