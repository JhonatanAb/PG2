<?php

class ControladorClientes{

/*=============================================
	MOSTRAR CLIENTES
	=============================================*/

	static public function ctrMostrarClientes($item, $valor){

		$tabla = "clientes";

		$respuesta = ModeloClientes::mdlMostrarClientes($tabla, $item, $valor);

		return $respuesta;

	}

	/*=============================================
	MOSTRAR CLIENTES
	=============================================*/

	static public function ctrMostrarClientesBySectorAndLocalidad($id_sector, $nombre_localidad){

		$tabla = "clientes";

		$respuesta = ModeloClientes::mdlMostrarClientesBySectorAndLocalidad($id_sector, $nombre_localidad);

		return $respuesta;

	}


	/*=============================================
	SUMA TOTAL duplicados
	=============================================*/

	static public function ctrClientesNuevosSinCobrar(){
	    
	    $usuario = $_SESSION['id'];

		$respuesta = ModeloClientes::mdlClientesNuevosSinCobrar($usuario);

		return $respuesta;

	}

	/*=============================================
	SUMA TOTAL duplicados
	=============================================*/

	static public function ctrClientesAtrasados(){
	    
	    $usuario = $_SESSION['id'];

		$respuesta = ModeloClientes::mdlClientesAtrasados($usuario);

		return $respuesta;

	}
	
	
	/*=============================================
	MOSTRAR CLIENTES
	=============================================*/

	static public function ctrMostrarClientesCd($item, $valor){

		$tabla = "clientes";

		$respuesta = ModeloClientes::mdlMostrarClientesCd($tabla, $item, $valor);

		return $respuesta;

	}

	/*=============================================
	MOSTRAR CLIENTES
	=============================================*/

	static public function ctrMostrarClientesSuspendidos($item, $valor){

		$tabla = "clientes";

		$respuesta = ModeloClientes::mdlMostrarClientesSuspendidos($tabla, $item, $valor);

		return $respuesta;

	}

	/*=============================================
	MOSTRAR CLIENTES
	=============================================*/

	static public function ctrMostrarClientesArea($area){

		$tabla = "clientes";

		$respuesta = ModeloClientes::mdlMostrarClientesArea($tabla, $area);

		return $respuesta;

	}

	/*=============================================
	MOSTRAR CLIENTES
	=============================================*/

	static public function ctrMostrarClientesCobrador($item){

		$cobrador = $_SESSION['id'];
		if($cobrador == 101 || $cobrador == 102){
		    $respuesta = ModeloClientes::mdlMostrarClientesAlameda();
		}else{
		$respuesta = ModeloClientes::mdlMostrarClientesCobrador($cobrador);
		}

		return $respuesta;

	}


	/*=============================================
	MOSTRAR CLIENTES COBRAR
	=============================================*/

	static public function ctrMostrarClientesCobrar($idCliente){

		$respuesta = ModeloClientes::mdlMostrarClientesCobrar($idCliente);

		return $respuesta;

	}


	/*=============================================
	COBRAR CLIENTE
	=============================================*/

	static public function ctrCobrarCliente(){

		if(isset($_POST["cobrarIdCliente"])){

			if(preg_match('/^[a-zA-Z0-9ñÑáéíóúÁÉÍÓÚ ]+$/', $_POST["cobrarIdCliente"])){

				$tabla = "pago";
				
				$item = "id_area";
        $valor = $_POST["cobrarIdArea"];
        $respuestaArea = ModeloAreas::mdlMostrarAreasId($item, $valor);
        $encabezado =$respuestaArea["empresa"];

				$totalPrecioServicio = $_POST["cobrarPrecioServicio"] * $_POST["cantidadMeses"];

				if ($_POST["cobrarPrecioTotal"] != $totalPrecioServicio) {
					$tipopago = "especial";
				}if ($_POST["cobrarPrecioTotal"] == $totalPrecioServicio) {
					$tipopago = "normal";
				}


				$totalmes = $_POST["cobrarIdMes"] + $_POST["cantidadMeses"] ;

				if ($totalmes >= "13") {
					
					$nuevomes = $totalmes - 12;
					$ano = $_POST["cobrarAno"] + 1;

				}else{

					$nuevomes = $totalmes;
					$ano = $_POST["cobrarAno"];

				}
				date_default_timezone_set('America/Guatemala');

						$f = date('Y-m-d');
						$hora = date('H:i:s');

						if ($_POST['ubicacion'] == "clientes-area") {
							$fecha = $_POST['fechaCobro'];
						}
						if ($_POST['ubicacion'] != "clientes-area") {
							$fecha = $f;
						}
						$usuario = $_SESSION['id'];

				$fechaCorta = $fecha;
				/*
				$permitted_chars = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
				$comprobante = substr(str_shuffle($permitted_chars), 0, 6);
				*/
				$doc = "recibo";
				
				$comprobante = $_POST["comprobante"];
				$id_servicio = $_POST["cobrarServicio"];

			   	$datos = array("fecha_pago"=>$fecha,
					           "id_mes"=>$_POST["cobrarMes"],
					           "precio"=>$_POST["cobrarPrecioTotal"],
					           "ano"=>$ano,
					           "id_cliente"=>$_POST["cobrarIdCliente"],
					           "id_area"=>$_POST["cobrarIdArea"],
					           "id_sector"=>$_POST["cobrarIdSector"],
					           "comprobante"=>$comprobante,
					           "usuario"=>$usuario,
					           "doc"=>$doc,
					           "id_servicio"=>$_POST["cobrarServicio"],
					           "cant_mes"=>$_POST["cantidadMeses"],
					           "tipo"=>$tipopago);

			   	$respuesta = ModeloClientes::mdlCobrarCliente($tabla, $datos, $nuevomes, $fechaCorta);

			   	if($respuesta == "ok"){

					
					if ($encabezado == "TVGUATE S.A.") {
					    echo'<div id = "recibo"><h3 align="1">'.$encabezado.'</h3>';
						echo'<p align="1" size="2">Estado de cuenta</p>
						<p align="1" size="2">Centro comercial Metaterminal del norte, zona 18 local #247<br></p>
					<p align="1" size="2">Tel: 2267-5151 2267-5152</p>
					<p align="1" size="2">Whatsapp: 3568-4753</p><br>';
					}

					if ($encabezado == "SUCHIATE") {
					    echo'<div id = "recibo"><h3 align="1">'.$encabezado.'</h3>';
						echo'<p align="1" size="2">Estado de cuenta</p>
						<p align="1" size="2">Tel: 2267-5151 2267-5152</p>
					<p align="1" size="2">Whatsapp: 3589-0499</p><br>';
					}
					
					if ($encabezado == "CABELNET") {
					    echo'<div id = "recibo"><h3 align="1">'.$encabezado.'</h3>';
						echo'<p align="1" size="2">Estado de cuenta</p>
						<p align="1" size="2">Tel: 2267-5151 2267-5152</p>
					<p align="1" size="2">Whatsapp: 5852-6039</p><br>';
					}
					
					if ($encabezado == "UNINET") {
					    echo'<div id = "recibo"><h3 align="1">'.$encabezado.'</h3>';
					echo'<p align="1" size="2">Estado de cuenta</p>
					<p align="1" size="2">Whatsapp: 3568-4753</p><br>';
					}
					
					if ($encabezado == "UNICABLE" && $id_servicio == "INTERNET") {
					    echo'<div id = "recibo"><h3 align="1">TVGUATE S.A.</h3>';
					echo'<p align="1" size="2">Estado de cuenta</p>
					<p align="1" size="2">Whatsapp: 3589-0499</p><br>';
					}
					
					if ($encabezado == "UNICABLE" && $id_servicio == "CABLE") {
					    echo'<div id = "recibo"><h3 align="1">'.$encabezado.'</h3>';
					echo'<p align="1" size="2">Estado de cuenta</p>
					<p align="1" size="2">Whatsapp: 3589-0499</p><br>';
					}

						echo'<p align="0" size="2">Fecha:'.$fecha.$hora.'</p>
					<p align="0" size="2">Comprobante:'.$comprobante.'</p>
					<p align="0" size="2">Cliente #:'.$_POST["cobrarIdCliente"].'</p>
					<p align="0" size="2">Nombre:'.$_POST["cobrarNombre"].'</p>
					<p align="0" size="2">Direccion:'.$_POST["cobrarDireccion"].'</p><br>

	
	<table>
  <tr>
    <th size="2" colspan="2">'.$_POST["cobrarServicio"].'" "'. $_POST["cobrarMes"].'</th>
    <th size="2"  align="2">Q.'.$_POST["cobrarPrecioTotal"].'</th>
  </tr>

</table><br>

<p align="2" size="2">TOTAL:'.$_POST["cobrarPrecioTotal"].'</p><br>
<p align="0" size="1">Cobrador:'.$_POST["cobrarCobrador"].'</p>
<p align="1" size="2">¡Gracias por utilizar nuestros servicios!</p><br>

					</div>';

				echo'<script>
				
				Swal.fire({
					  icon: "success",
					  title: "Guardado correctamente",
					  showConfirmButton: true,
					  confirmButtonText: "Cerrar",
					  closeOnConfirm: false
					  }).then(function(result) {
								if (result.value) {

								window.location="printerplus://send?text="+document.getElementById("recibo").innerHTML;
								window.location = "'.$_POST["ubicacion"].'";


								}
							})

				</script>';

				}

			}else{

				echo'<script>

					Swal({
						  type: "error",
						  title: "¡Error!",
						  showConfirmButton: true,
						  confirmButtonText: "Cerrar"
						  }).then(function(result){
							if (result.value) {

							window.location = "'.$_POST["ubicacion"].'";

							}
						})

			  	</script>';



			}

		}

	}

	/*=============================================
	COBRAR CLIENTE
	=============================================*/

	static public function ctrCobrarClienteOficina(){

		if(isset($_POST["cobrarIdCliente"])){

			if(preg_match('/^[a-zA-Z0-9ñÑáéíóúÁÉÍÓÚ ]+$/', $_POST["cobrarIdCliente"])){

				$tabla = "pago";
				
				$item = "id_area";
        $valor = $_POST["cobrarIdArea"];
        $respuestaArea = ModeloAreas::mdlMostrarAreasId($item, $valor);
        $encabezado =$respuestaArea["empresa"];

				$totalPrecioServicio = $_POST["cobrarPrecioServicio"] * $_POST["cantidadMeses"];

				if ($_POST["cobrarPrecioTotal"] != $totalPrecioServicio) {
					$tipopago = "especial";
				}if ($_POST["cobrarPrecioTotal"] == $totalPrecioServicio) {
					$tipopago = "normal";
				}


				$totalmes = $_POST["cobrarIdMes"] + $_POST["cantidadMeses"] ;

				if ($totalmes >= "13") {
					
					$nuevomes = $totalmes - 12;
					$ano = $_POST["cobrarAno"] + 1;

				}else{

					$nuevomes = $totalmes;
					$ano = $_POST["cobrarAno"];

				}
				date_default_timezone_set('America/Guatemala');

						$f = date('Y-m-d');
						$hora = date('H:i:s');

						if ($_POST['ubicacion'] == "clientes-area") {
							$fecha = $_POST['fechaCobro'];
						}
						if ($_POST['ubicacion'] != "clientes-area") {
							$fecha = $f;
						}
						$usuario = $_SESSION['id'];

				$fechaCorta = $fecha;
				/*
				$permitted_chars = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
				$comprobante = substr(str_shuffle($permitted_chars), 0, 6);
				*/
				$doc = "recibo";
				
				$comprobante = $_POST["comprobante"];

			   	$datos = array("fecha_pago"=>$fecha,
					           "id_mes"=>$_POST["cobrarMes"],
					           "precio"=>$_POST["cobrarPrecioTotal"],
					           "ano"=>$ano,
					           "id_cliente"=>$_POST["cobrarIdCliente"],
					           "id_area"=>$_POST["cobrarIdArea"],
					           "id_sector"=>$_POST["cobrarIdSector"],
					           "comprobante"=>$comprobante,
					           "usuario"=>$usuario,
					           "doc"=>$doc,
					           "id_servicio"=>$_POST["cobrarServicio"],
					           "cant_mes"=>$_POST["cantidadMeses"],
					           "tipo"=>$tipopago);

			   	$respuesta = ModeloClientes::mdlCobrarCliente($tabla, $datos, $nuevomes, $fechaCorta);

			   	if($respuesta == "ok"){

					echo'

					<form id="recibotvg"  action="http://localhost/recibotvg/index.php" method="POST">
	 
              
                	  <input type="text" class="form-control input-lg" name="comprobante" value="'.$comprobante.'">
                	   <input type="text" class="form-control input-lg" name="codigocliente" value="'.$_POST["cobrarIdCliente"].'">
                	    <input type="text" class="form-control input-lg" name="nombre" value="'.$_POST["cobrarNombre"].'">
                	    <input type="text" class="form-control input-lg" name="direccion" value="'.$_POST["cobrarDireccion"].'">
                	    <input type="text" class="form-control input-lg" name="descripcion" value="'.$_POST["cobrarServicio"]."-".$_POST["cobrarMes"].'">
                	    <input type="text" class="form-control input-lg" name="total" value="'.$_POST["cobrarPrecioTotal"].'">
                	    <input type="text" class="form-control input-lg" name="cobrador" value="'.$_POST["cobrarCobrador"].'">
                	    <input type="text" class="form-control input-lg" name="ubicacion" value="'.$_POST["ubicacion"].'">
                
				</form>';

				echo'<script>
				
				Swal.fire({
					  icon: "success",
					  title: "Guardado correctamente",
					  showConfirmButton: true,
					  confirmButtonText: "Cerrar",
					  closeOnConfirm: false
					  }).then(function(result) {
								if (result.value) {

								
								window.location = "'.$_POST["ubicacion"].'";
								document.getElementById("recibotvg").submit();


								}
							})

				</script>';

				}

			}else{

				echo'<script>

					Swal({
						  type: "error",
						  title: "¡Error!",
						  showConfirmButton: true,
						  confirmButtonText: "Cerrar"
						  }).then(function(result){
							if (result.value) {

							window.location = "'.$_POST["ubicacion"].'";

							}
						})

			  	</script>';



			}

		}

	}

	/*=============================================
	COBRAR CLIENTE
	=============================================*/

	static public function ctrCobrarClienteFactura(){

		if(isset($_POST["ftCobrarIdCliente"])){

			if(preg_match('/^[a-zA-Z0-9ñÑáéíóúÁÉÍÓÚ ]+$/', $_POST["ftCobrarIdCliente"])){

			date_default_timezone_set('America/Guatemala');

						$f = date('Y-m-d');
						$hora = date('H:i:s');
						$fecha = $f;

					
				$tabla = "pago";
				
				$totalPrecioServicio = $_POST["ftCobrarPrecioServicio"] * $_POST["ftCantidadMeses"];

				if ($_POST["ftCobrarPrecioTotal"] != $totalPrecioServicio) {
					$tipopago = "especial";
				}if ($_POST["ftCobrarPrecioTotal"] == $totalPrecioServicio) {
					$tipopago = "normal";
				}


				$totalmes = $_POST["ftCobrarIdMes"] + $_POST["ftCantidadMeses"] ;

				if ($totalmes >= "13") {
					
					$nuevomes = $totalmes - 12;
					$ano = $_POST["ftCobrarAno"] + 1;

				}else{

					$nuevomes = $totalmes;
					$ano = $_POST["ftCobrarAno"];

				}
				
						
						$usuario = $_SESSION['id'];

				$fechaCorta = $fecha;
				/*
				$permitted_chars = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
				$comprobante = substr(str_shuffle($permitted_chars), 0, 6);
				*/
				$doc = "recibo";
				
				$comprobante = $_POST["ftComprobante"];

			   	$datos = array("fecha_pago"=>$fecha,
					           "id_mes"=>$_POST["ftCobrarMes"],
					           "precio"=>$_POST["ftCobrarPrecioTotal"],
					           "ano"=>$ano,
					           "id_cliente"=>$_POST["ftCobrarIdCliente"],
					           "id_area"=>$_POST["ftCobrarIdArea"],
					           "id_sector"=>$_POST["ftCobrarIdSector"],
					           "comprobante"=>$comprobante,
					           "usuario"=>$usuario,
					           "doc"=>$doc,
					           "id_servicio"=>$_POST["ftCobrarServicio"],
					           "cant_mes"=>$_POST["ftCantidadMeses"],
					           "tipo"=>$tipopago);

			   	$respuesta = ModeloClientes::mdlCobrarCliente($tabla, $datos, $nuevomes, $fechaCorta);

			   	if($respuesta == "ok"){

				echo'<script>
				
				Swal.fire({
					  icon: "success",
					  title: "Guardado correctamente",
					  showConfirmButton: true,
					  confirmButtonText: "Cerrar",
					  closeOnConfirm: false
					  }).then(function(result) {
								if (result.value) {

								window.location = "factura-datos";


								}
							})

				</script>';

				}

			}else{

				echo'<script>

					Swal.fire({
						  type: "error",
						  title: "¡Error!",
						  showConfirmButton: true,
						  confirmButtonText: "Cerrar"
						  }).then(function(result){
							if (result.value) {

							window.location = "'.$_POST["ftUbicacion"].'";

							}
						})

			  	</script>';



			}

		}

	}


	/*=============================================
	COBRAR CLIENTE
	=============================================*/

	static public function ctrGuardarFacTemp(){

		if(isset($_POST["facIdCliente"])){

			if(preg_match('/^[a-zA-Z0-9ñÑáéíóúÁÉÍÓÚ ]+$/', $_POST["facIdCliente"])){

				$tabla = "fac_temp";
				date_default_timezone_set('America/Guatemala');

						$fecha = date('Y-m-d');

			   	$datos = array("id_cliente"=>$_POST["facIdCliente"],
					           "receptor_nit"=>$_POST["facNit"],
					           "receptor_nombre"=>$_POST["facNombre"],
					           "fecha_hora"=>$_POST["facFecha"],
					           "autorizacion"=>$_POST["facAutorizacion"],
					           "serie"=>$_POST["facSerie"],
					           "numero"=>$_POST["facNumero"],
					           "usuario"=>$_POST["facUsuario"],
					           "total"=>$_POST["facTotal"],
					           "descripcion"=>$_POST["facDescripcion"],
					           "fecha_guardo"=>$fecha);

			   	$respuesta = ModeloClientes::mdlGuardarFacTemp($tabla, $datos, $nuevomes, $fechaCorta);

			   		if($respuesta == "ok"){
				echo'<script>
				
				Swal.fire({
					  icon: "success",
					  title: "DATOS GUARDADOS CORECTAMENTE ",
					  showConfirmButton: true,
					  confirmButtonText: "Cerrar",
					  closeOnConfirm: false
					  }).then(function(result) {
								if (result.value) {
								window.location = "'.$_POST["facUbicacion"].'";


								}
							})

				</script>';

				
			}
			}else{

				echo'<script>

					Swal({
						  type: "error",
						  title: "¡Error!",
						  showConfirmButton: true,
						  confirmButtonText: "Cerrar"
						  }).then(function(result){
							if (result.value) {

							window.location = "'.$_POST["facUbicacion"].'";

							}
						})

			  	</script>';



			}

		}

	}


	/*=============================================
	COBRAR CLIENTE
	=============================================*/

	static public function ctrReimprimirCliente(){
		if(isset($_POST["codigoCliente"])){
				if(preg_match('/^[a-zA-Z0-9ñÑáéíóúÁÉÍÓÚ ]+$/', $_POST["codigoCliente"])){
				
					 	$cobrador = $_SESSION['id'];
            $respuestaPago = ModeloPagos::mdlMostrarPagosUlt2($cobrador);


            if ($respuestaPago["estado"] == 0 && $respuestaPago["comprobante"] == $_POST['comprobante'] ) {
            	
					date_default_timezone_set('America/Guatemala');

						$fecha = date('Y-m-d');
						$hora = date('H:i:s');
						$encabezado = $_POST['encabezado'];

					echo'<div id = "recibo"><h3 align="1">'.$encabezado.'</h3>';
					if ($encabezado == "TVGUATE S.A.") {
						echo'<p align="1" size="2">Estado de cuenta</p>
						<p align="1" size="2">Centro comercial Metaterminal del norte, zona 18 local #247<br></p>
					<p align="1" size="2">Tel: 2267-5151 2267-5152</p>
					<p align="1" size="2">Whatsapp: 3568-4753</p><br>';
					}

					if ($encabezado == "SUCHIATE") {
						echo'<p align="1" size="2">Estado de cuenta</p>
						<p align="1" size="2">Tel: 2267-5151 2267-5152</p>
					<p align="1" size="2">Whatsapp: 3589-0499</p><br>';
					}
					
					if ($encabezado == "CABELNET") {
						echo'<p align="1" size="2">Estado de cuenta</p>
						<p align="1" size="2">Tel: 2267-5151 2267-5152</p>
					<p align="1" size="2">Whatsapp: 5852-6039</p><br>';
					}
					
					if ($encabezado == "UNINET") {
					echo'<p align="1" size="2">Estado de cuenta</p>
					<p align="1" size="2">Whatsapp: 3568-4753</p><br>';
					}

						echo'<p align="0" size="2">Fecha:'.$fecha.$hora.'</p>
					<p align="0" size="2">Comprobante:'.$_POST["comprobante"].'</p>
					<p align="0" size="2">Cliente #:'.$_POST["codigoCliente"].'</p>
					<p align="0" size="2">Nombre:'.$_POST["nombreCliente"].'</p>
					<p align="0" size="2">Direccion:'.$_POST["direccionCliente"].'</p><br>

	
	<table>
  <tr>
    <th size="2" colspan="2">'.$_POST["servicioCobrado"].'" "'. $_POST["mesCobrado"].'</th>
    <th size="2"  align="2">Q.'.$_POST["totalCobrado"].'</th>
  </tr>

</table><br>

<p align="2" size="2">TOTAL:'.$_POST["totalCobrado"].'</p><br>
<p align="0" size="1">Cobrador:'.$_POST["cobrador"].'</p>
<p align="1" size="2">¡Gracias por utilizar nuestros servicios!</p><br>

					</div>';

				echo'<script>
				
				Swal.fire({
					  icon: "success",
					  title: "Enviado correctamente",
					  showConfirmButton: true,
					  confirmButtonText: "Cerrar",
					  closeOnConfirm: false
					  }).then(function(result) {
								if (result.value) {

								window.location="printerplus://send?text="+document.getElementById("recibo").innerHTML;
								window.location = "'.$_POST["ubicacion"].'";


								}
							})

				</script>';


            }
            else{

            	echo'<script>

					Swal.fire({
						  type: "error",
						  title: "¡ERROR, el cobro no aplica para reimpresion!",
						  showConfirmButton: true,
						  confirmButtonText: "Cerrar"
						  }).then(function(result){
							if (result.value) {

							window.location = "'.$_POST["ubicacion"].'";

							}
						})

			  	</script>';
            }

		}	
	}

	}

	/*=============================================
	CREAR CLIENTES
	=============================================*/

	static public function ctrCrearCliente(){

		if(isset($_POST["nuevoNombre"])){

			if(preg_match('/^[a-zA-Z0-9ñÑáéíóúÁÉÍÓÚ ]+$/', $_POST["nuevoNombre"])){

				

					$redireccionar = $_POST['redireccionar'];
			   	$tabla = "clientes";
			   	$telefono = $_POST["nuevoTelefono"];
			   	$datos = array("nombre"=>$_POST["nuevoNombre"],
					           "telefono"=>$_POST["nuevoTelefono"],
					            "nit"=>$_POST["nuevoNit"],
					           "id_area"=>$_POST["area"],
					           "id_sector"=>$_POST["sector"],
					           "referencia"=>$_POST["nuevoReferencia"],
					           "localidad"=>$_POST["nuevoLocalidad"],
					           "id_servicio"=>$_POST["nuevoServicio"],
					           "fecha_instalacion"=>$_POST["nuevoFechaInstalacion"],
					           "observacion"=>$_POST["nuevoObservacion"],
					           "precio"=>$_POST["nuevoPrecio"],
					           "id_mes"=>$_POST["nuevoMes"],
					           "ano"=>$_POST["nuevoAno"],
					           "instalador"=>$_POST["nuevoInstalador"]);

			   	$respuesta = ModeloClientes::mdlIngresarCliente($tabla, $datos);

			   	if($respuesta == "ok"){

					echo'<script>

					Swal.fire({
						  type: "success",
						  title: "El cliente ha sido guardado correctamente",
						  showConfirmButton: true,
						  confirmButtonText: "Cerrar"
						  }).then(function(result){
									if (result.value) {

									window.location = "'.$redireccionar.'";

									}
								})

					</script>';

				}

			}else{

				echo'<script>

					Swal.fire({
						  type: "error",
						  title: "¡El cliente no puede ir vacío o llevar caracteres especiales!",
						  showConfirmButton: true,
						  confirmButtonText: "Cerrar"
						  }).then(function(result){
							if (result.value) {

							window.location = "'.$redireccionar.'";

							}
						})

			  	</script>';



			}

		}

	}

/*=============================================
	EDITAR CLIENTE
	=============================================*/

	static public function ctrEditarCliente(){

		if(isset($_POST["editarNombre"])){

			if(preg_match('/^[a-zA-Z0-9ñÑáéíóúÁÉÍÓÚ ]+$/', $_POST["editarNombre"])){

			   	$tabla = "clientes";

			   	if ($_POST["editarArea"] == "") {

			   		$area=$_POST["areaActual"];
			   	}

			   		if ($_POST["editarArea"] != "") {

			   		$area=$_POST["editarArea"];

			   	}

			   	if ($_POST["editarSector"] == "") {

			   		$sector=$_POST["sectorActual"];
			   	}
			   	if ($_POST["editarSector"] != "") {

			   		$sector=$_POST["editarSector"];

			   	}

			   	//Demilitador 'i' para no diferenciar mayus y minus
					if (preg_match("/ave/i", $_POST["editarLocalidad"])) 
				    {
				    $iddir="ave";
				    }else 
					    {
				        $iddir="";
					    }

			   	$redireccionar = $_POST['redireccionar'];

			   	$datos = array("id"=>$_POST["editarId"],
			   				   "nombre"=>$_POST["editarNombre"],
					           "telefono"=>$_POST["editarTelefono"],
					           "nit"=>$_POST["editarNit"],
					           "localidad"=>$_POST["editarLocalidad"],
					           "referencia"=>$_POST["editarReferencia"],
					       	   "id_servicio"=>$_POST["editarServicio"],
					       	   "id_mes"=>$_POST["editarMes"],
					       	    "precio"=>$_POST["editarPrecio"],
					       	     "ano"=>$_POST["editarAno"],
					       	      "observacion"=>$_POST["editarObservacion"],
					       	       "fecha_instalacion"=>$_POST["editarFechaInstalacion"],
					       	   "id_area"=>$area,
					       	   "id_sector"=>$sector,
					       	   "iddir"=>$iddir);

			   	$respuesta = ModeloClientes::mdlEditarCliente($tabla, $datos);

			   	if($respuesta == "ok"){

					echo'<script>

					Swal.fire({
						  type: "success",
						  title: "El cliente ha sido cambiado correctamente",
						  showConfirmButton: true,
						  confirmButtonText: "Cerrar"
						  }).then(function(result){
									if (result.value) {

									window.location = "'.$redireccionar.'";

									}
								})

					</script>';

				}

			}else{

				echo'<script>

					Swal.fire({
						  type: "error",
						  title: "¡El cliente no puede ir vacío o llevar caracteres especiales!",
						  showConfirmButton: true,
						  confirmButtonText: "Cerrar"
						  }).then(function(result){
							if (result.value) {

							window.location = "'.$redireccionar.'";

							}
						})

			  	</script>';



			}

		}

	}


/*=============================================
	ELIMINAR CLIENTE
	=============================================*/

	static public function ctrEliminarCliente(){

		if(isset($_GET["idCliente"])){

			$tabla ="clientes";
			$datos = $_GET["idCliente"];

			$respuesta = ModeloClientes::mdlEliminarCliente($tabla, $datos);

			if($respuesta == "ok"){

				echo'<script>

				Swal.fire({
					  type: "success",
					  title: "El cliente ha sido borrado correctamente",
					  showConfirmButton: true,
					  confirmButtonText: "Cerrar",
					  closeOnConfirm: false
					  }).then(function(result){
								if (result.value) {

								window.location = "clientes";

								}
							})

				</script>';

			}		

		}

	}


static public function ctrMostrarListadoClientes($servicio, $area){

		$tabla = "clientes";

		$respuesta = ModeloClientes::MdlMostrarListadoClientes($tabla, $servicio, $area);

		return $respuesta;

	}

	static public function ctrMostrarListadoClientesDeuda($servicio, $area, $fecha){

		$tabla = "clientes";

		$respuesta = ModeloClientes::MdlMostrarListadoClientesDeuda($tabla, $servicio, $area, $fecha);

		return $respuesta;

	}


}

