<?php

 

      $_SESSION["sector-solicitud"] = $_POST["sector"];

      echo '<script>

								window.location = "mostrar-solicitudes-sector";

							</script>';
      

?>