<?php

 

      $_SESSION["clientes-area"] = $_POST["area"];

      echo '<script>

								window.location = "clientes-area";

							</script>';
      

?>