<?php

 

      $_SESSION["sector-usuario"] = $_POST["usuario"];

      echo '<script>

								window.location = "usuarios-perfil";

							</script>';
      

?>